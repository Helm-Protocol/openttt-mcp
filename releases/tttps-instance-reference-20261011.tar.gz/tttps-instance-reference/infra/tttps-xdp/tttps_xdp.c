#include <linux/bpf.h>
#include <linux/if_ether.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/in.h>

#define SEC(NAME) __attribute__((section(NAME), used))
#define NS_PER_SECOND 1000000000ULL
#define TTTPS_8443 0
#define TTTPS_8090 1

#define __uint(name, val) int (*name)[val]
#define __type(name, val) typeof(val) *name

struct port_bucket {
    __u64 window_start_ns;
    __u32 packets;
    __u32 drops;
};

struct {
    __uint(type, BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 2);
    __type(key, __u32);
    __type(value, __u32);
} limits SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 2);
    __type(key, __u32);
    __type(value, struct port_bucket);
} buckets SEC(".maps");

static void *(*map_lookup_elem)(void *map, const void *key) = (void *)1;
static __u64 (*ktime_get_ns)(void) = (void *)5;
static long (*map_update_elem)(void *map, const void *key, const void *value, __u64 flags) = (void *)2;

struct {
    __uint(type, BPF_MAP_TYPE_LRU_HASH);
    __uint(max_entries, 4096);
    __type(key, __u32);
    __type(value, struct port_bucket);
} source_buckets SEC(".maps");

static __always_inline int rate_limit(__u32 key, __u32 source_ip)
{
    __u64 now = ktime_get_ns();
    __u32 default_limit = key == TTTPS_8443 ? 20000 : 5000;
    __u32 *configured = map_lookup_elem(&limits, &key);
    __u32 limit = (configured && *configured) ? *configured : default_limit;
    struct port_bucket *bucket = map_lookup_elem(&buckets, &key);
    __u32 source_limit = 2000;
    struct port_bucket *source = map_lookup_elem(&source_buckets, &source_ip);
    if (!source) {
        struct port_bucket initial = { .window_start_ns = now, .packets = 1, .drops = 0 };
        map_update_elem(&source_buckets, &source_ip, &initial, BPF_ANY);
    } else {
        if (source->window_start_ns == 0 || now - source->window_start_ns >= NS_PER_SECOND) {
            source->window_start_ns = now;
            source->packets = 0;
        }
        if (source->packets >= source_limit) {
            source->drops++;
            return XDP_DROP;
        }
        source->packets++;
    }

    if (!bucket)
        return XDP_PASS;
    if (bucket->window_start_ns == 0 ||
        now - bucket->window_start_ns >= NS_PER_SECOND) {
        bucket->window_start_ns = now;
        bucket->packets = 0;
    }
    if (bucket->packets >= limit) {
        bucket->drops++;
        return XDP_DROP;
    }
    bucket->packets++;
    return XDP_PASS;
}

SEC("xdp")
int tttps_xdp(struct xdp_md *ctx)
{
    void *data = (void *)(long)ctx->data;
    void *data_end = (void *)(long)ctx->data_end;
    struct ethhdr *eth = data;
    struct iphdr *ip;
    struct tcphdr *tcp;
    __u32 key;

    if ((void *)(eth + 1) > data_end || eth->h_proto != __constant_htons(ETH_P_IP))
        return XDP_PASS;
    ip = (void *)(eth + 1);
    if ((void *)(ip + 1) > data_end || ip->protocol != IPPROTO_TCP)
        return XDP_PASS;
    if (ip->ihl < 5 || (void *)ip + ip->ihl * 4 > data_end)
        return XDP_PASS;
    tcp = (void *)ip + ip->ihl * 4;
    if ((void *)(tcp + 1) > data_end)
        return XDP_PASS;

    if (tcp->dest == __constant_htons(8443))
        key = TTTPS_8443;
    else if (tcp->dest == __constant_htons(8090))
        key = TTTPS_8090;
    else
        return XDP_PASS;
    return rate_limit(key, ip->saddr);
}

char LICENSE[] SEC("license") = "GPL";
